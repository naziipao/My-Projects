// for documented resources visit : https://developer.mozilla.org/en-US/

/*
--------------------------
    Conditional Statement
--------------------------
*/

let age = 21;

if(age > 18){
    if(age % 2 == 0){
        console.log("your age is even.");
    }
    else{
        console.log("your age is odd.");
    }
    console.log("You are eligible to vote.");
}

else{
    console.log("You are not eligible to vote.");
}

//Else if is also similar as Java


//* Ternary Operator --> if cond1 is true ? keep cond1 : else keep cond2


let result = age >= 18 ? "Adult" : "Not adult";  // If the 
alert("Ternary answer = " + result)

// let userInput = prompt("Hello")  //--> Similar to alert but it takes input from user and returns the value in string format.
// console.log("User input = " + userInput)  //--> It will print the value entered by user in console. 

let promptInput = prompt("Enter a number ");
if(promptInput % 5 == 0){
    console.log("User input is divisible by 5.");
}
else{
    console.log("User input is not divisible by 5.");
}