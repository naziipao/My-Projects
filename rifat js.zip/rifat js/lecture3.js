/*
--------------------------
    Loops and Strings 
--------------------------
*/


// For Loop:

for(let i = 1; i <=5; i++){
    console.log("For loop: " + i);
}

// While Loop:

let i = 1;
while(i<=5){
    console.log("While loop: " + i);
    i++;
}

/*Do-While Loop:
Works like While loop but executs atleast for one time even if the condition is false.

    do{
        //do some work
    }
    while(condition);
*/

let j = 20;
do{
    console.log("Do-While loop: " + j);
}
while(j>=20);


// For-of Loop: Used to iterate over iterable objects like arrays, strings, etc.

let str = "Hello";

for(let i of str){
    console.log(i); //Prints H , e , l , l , o separately.
}



//For-in Loop: Used to iterate over the properties of an object.

let student = {
    name: "Nazif",
    age: 23,
    grade: "A",
    isPass : true,
};
for(let i in student){
    console.log(i)
}